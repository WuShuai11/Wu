

Page({
  properties: {
    index: {
      type: Number,
      observer: function () {

      }
    }
  },

  data: {

  },
  onLoad: function () {

  }

})